package bingo_project;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author mati
 */
public class Bingo_Project {
    
    //constantes que limitan la matriz
    private static final int _X = 5;
    private static final int _Y = 3;
    private static final int _BOMBO = 99;
    //constante premio:
    private static final int _PREMIO = 2000;
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        String jugador1, jugador2;
        
        int bola = 0;
        
        int[][] cartonjugador1 = new int[_X][_Y];
        int[][] cartonjugador2 = new int[_X][_Y];
        String[][] cartonStringJ1 = new String[_X][_Y];
        String[][] cartonStringJ2 = new String[_X][_Y];
        int[] bolas = new int[_BOMBO];
        boolean ganadorJ1 = false, ganadorJ2 = false;
        
        //variable que controla las bolas que vamos añadiendo al array de bolas
        int i = 0;
        int turno = 1;
        
        boolean ver = false;
        
        System.out.println("Primer jugador, por favor, introduce tu nombre: ");
        jugador1 = sc.next();
        
        System.out.println("Segundo jugador, por favor, introduce tu nombre: ");
        jugador2 = sc.next();
        
        
        cargaCarton(cartonjugador1);
        cargaCarton(cartonjugador2);
        
        pantallaJuego(cartonjugador1, cartonjugador2, cartonStringJ1, cartonStringJ2, bola, jugador1, jugador2);
        
        do{
            
            System.out.println("TURNO: " +turno);
            
            bola = cargaBola();
            
            /*
             TODO LOGICA DEL JUEGO
            */
            comprobarBola(cartonjugador1, bola);
            comprobarBola(cartonjugador2, bola);
            
            ganadorJ1 = noGanador(cartonjugador1);
            ganadorJ2 = noGanador(cartonjugador2);
            
            pantallaJuego(cartonjugador1, cartonjugador2, cartonStringJ1, cartonStringJ2, bola, jugador1, jugador2);
            
            bolas[i] = bola;
            
            i++;
            
            ver = mostrarBolas();
            
            if(ver){
                mostrarArrayBolas(bolas);
            }
            
            turno++;
            ver = false; //reiniciamos ver a false para que siga preguntando
            
        }while(!ganadorJ1 && !ganadorJ2 && i < _BOMBO);
        
        
        
        
        
    }
    
    /**
     * Llena de valores aleatorios el cartón de cada jugador
     * @param carton el carton que recibirá los datos
     */
    public static void cargaCarton(int[][] carton){
        
        Random random = new Random();
        
        int randomNumero;
        
        for (int i = 0; i < _Y; i++) {
            for (int j = 0; j < _X; j++) { 
                
                randomNumero = random.nextInt(99)+1;
                
                while(!noRepetirNumeros(carton,randomNumero)){
                    randomNumero = random.nextInt(99)+1;
                    
                }
                
                carton[j][i]= randomNumero;
                
                
            }
            
        }
        
        
    }
    
    /**
     * Función que cargará los datos de cada jugador
     * @param carton el carton del jugador
     * @param nombre el nombre del jugador
     */
    public static void mostrarJugador(int[][] carton, String nombre, String[][] cartonString){
        
        
        
        
        /*for (int i = 0; i < _Y; i++) {
            for (int j = 0; j < _X; j++) {                
                System.out.print(carton[j][i] +" ");                
            }
            
            System.out.println("");
            
        }*/
        
        
        
        System.out.println("****** JUGADOR "+nombre+" *************");
        
        for (int i = 0; i < _Y; i++) {
            for (int j = 0; j < _X; j++) {
                
                cartonString[j][i] = Integer.valueOf(carton[j][i]).toString();
                
                if(cartonString[j][i].equals("-1")){
                    cartonString[j][i] = "X";
                }
                
                System.out.print(cartonString[j][i] + " ");
                
            }
            
            System.out.println("");
        }
        
        System.out.println("*********************************");
        
    }
    
    /**
     * Función que da valor aleatorio a la bola
     * @param bola la bola del bombo
     */
    public static int cargaBola(){
        
        Random rnd = new Random();
        
        int bola = rnd.nextInt(99)+1;
        
        return bola;
        
    }
    
    /**
     * Función que evita repetir números en una matriz 
     * @param carton el cartón donde vamos a cargar datos
     * @param numero el número a controlar
     * @return true en caso de repetido, false en caso contrario
     */
    public static boolean noRepetirNumeros(int[][] carton, int numero){
        
        boolean isRepetido = true;
        
        for (int i = 0; i < _Y; i++) {
            for (int j = 0; j < _X; j++) {                
                if(numero == carton[j][i]){
                    isRepetido = false;
                }
            }
            
        }
        
        
        return isRepetido;
        
    }
    
    /**
     * Muestra por pantalla los datos de cada jugada
     * @param jugador1 la matriz con el cartón de juego del jugador 1
     * @param jugador2 la matriz con el cartón de juego del jugador 1
     * @param stringJ1 cartón del jugador para poder mostrar X
     * @param stringJ2 cartón del jugador para poder mostrar X
     * @param bola el valor de la bola
     * @param nombreJ1 el nombre del primer jugador
     * @param nombreJ2 el nombre del segundo jugador
     */
    public static void pantallaJuego(int[][] jugador1, int[][] jugador2, String[][] stringJ1, String[][] stringJ2, int bola, String nombreJ1, String nombreJ2){
        
        
        System.out.println("Premio: " +_PREMIO);
        System.out.println("Bola: " +bola);
        
        mostrarJugador(jugador1, nombreJ1, stringJ1);
        
        System.out.println("");
        
        mostrarJugador(jugador2, nombreJ2, stringJ2);
        
        System.out.println("");
        
        System.out.println("*********************************");
        
        
        
    }
    
    public static boolean noGanador(int carton[][]){
        
        boolean isGanador = false;
        int cuentaAciertos = 0;
        
        for (int i = 0; i < _Y; i++) {
            for (int j = 0; j < _X; j++) {
                
                if(carton[j][i] == -1){
                    cuentaAciertos++;
                }
                
            }
        }
        
        if(cuentaAciertos == 15){
            isGanador = true;
        }
        
        
        
        return isGanador;
    }
    
    /**
     * Pide al usuario si quiere ver o no las bolas que han salido hasta el momento
     * @return true en caso de confirmación, false si no es así
     */
    private static boolean mostrarBolas() {
        
        boolean mostrar = false;
        char confirmar = ' ';
        
        Scanner sc = new Scanner(System.in);
        
        
        while(confirmar != 'y' && confirmar != 'Y' && confirmar != 'n' && confirmar != 'N'){
            System.out.println("¿Quieres ver las bolas que han salido (Y/N)?");
            confirmar = sc.next().charAt(0);
        }
        
        if(confirmar == 'y' || confirmar == 'Y'){
          mostrar = true;  
        }
        
        
        return mostrar;
    }
    
    /**
     * Muestra las bolas del bombo
     * @param bombo el array con las bolas
     */
    private static void mostrarArrayBolas(int bombo[]){
        
        System.out.println("Los numeros que han salido son: ");
        
        for (int i = 0; i < _BOMBO; i++) {
            
            if(bombo[i] != 0){
                System.out.print(bombo[i] + " ");
            }
            
            
        }
        
        System.out.println("");
        
    }
    
    public static void comprobarBola(int[][] carton, int bola){
        
        
        for (int i = 0; i < _Y; i++) {
            for (int j = 0; j < _X; j++) {
                
                if(bola == carton[j][i]){
                    carton[j][i] = -1;
                }
                
            }
        }
        
        
    }
    
}
