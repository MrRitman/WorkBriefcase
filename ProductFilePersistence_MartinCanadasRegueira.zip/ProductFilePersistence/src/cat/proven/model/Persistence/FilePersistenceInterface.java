
package cat.proven.model.Persistence;

import cat.proven.model.Product;
import java.io.File;
import java.util.List;

/**
 *
 * @author mati
 */
public interface FilePersistenceInterface {
    
    /**
     * Creates a file with the given data
     * @param listOfProd the data to write
     * @return true if correct, false if fails
     */
    public boolean writeFile(List<Product> listOfProd, String file);
    /**
     * Read data from selected file
     * @param file 
     */
    public List<Product> readFile(String file);
   

    
}
