/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.model.Persistence;

import cat.proven.model.Product;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mati
 */
public class Persistence implements FilePersistenceInterface{

    
    
    @Override
    public List<Product> readFile(String file) {
        
        
        
        List<Product> productList = new ArrayList<>();
        
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream (file))){
            
               Object obj;
               while ((obj = ois.readObject()) != null){
                   if(obj instanceof Product){
                       Product p = (Product) obj;
                       productList.add(p);
                   }
               }
            
        }catch (EOFException eofe){
            
        } catch (FileNotFoundException ex) {
            
            productList = null;
        } catch (IOException ex) {
            
            productList = null;
        } catch (ClassNotFoundException ex) {
            
            productList = null;
        }
        finally{
            
            return productList;
        }
        
        

        
    }

    @Override
    public boolean writeFile(List<Product> listOfProd, String file) {
        
        boolean fileExists = true;
        
        
       

        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream (file))){
            
            
            for (Product product : listOfProd) {
                
                oos.writeObject(product);
                
                
            }
            
            
            
            
        } catch (EOFException eofe) {    
            
        } catch (IOException ex) {
            //Logger.getLogger(Persistence.class.getName()).log(Level.SEVERE, null, ex);
            
            fileExists = false;
        }
        
        
        return fileExists;
        
    }

    
    
    
}
