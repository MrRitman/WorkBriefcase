/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author mati
 */
public class Model {
    //attributes
    List <Product> products;
    
    //contructor
    public Model() {
        this.products = new ArrayList<>();
        this.loadTestData();
    }
    
    //accessors.

    public int getNumProducts() {
        return products.size();
    }
    
    //methods.
    
    /**
     * retrieves all products from the data store.
     * @return list of all products or null in case of error.
     */
    public List<Product> listAllProducts() {
        return products;
    }
    
    /**
     * retrieves the element at position index.
     * @param index position of the element to retrieve.
     * @return element at the given position or null in case of error.
     */
    public Product get(int index) {
        Product p = null;
        if ((index >= 0) && (index < getNumProducts())) {
            p = products.get(index);
        }    
        return p;
    }

    /**
     * retrieves product with the given code from the data source.
     * @param code the code to search.
     * @return product with the given code or null if not found or in case of error.
     */
    public Product findProductByCode(String code) {
        Product result = null;
        Iterator<Product> iter = products.iterator();
        Product p;
        
        try{
            if(code!=null){  
                //while the product code differs from null
                while(iter.hasNext()){
                    //we will iterate
                    p = iter.next();
                    //until we find the product with the same code
                    if(p.getCode().equals(code)){
                        result = p;
                    }            
                }
            }
        }catch(NullPointerException ex){
            
        }
           
        return result;
        
    }
    
    /**
     * adds a product to the data source,
     * avoids adding null products or products with null code,
     * also avoids adding when list is full and when another product with 
     * the same code exists in the list.
     * @param product the product to add.
     * @return true if successfully added, false otherwise.
     */
    public boolean addProduct(Product product) {
        //variables
        boolean b = false;
        //check error conditions.
        if(findProductByCode(product.getCode())!=null){
            b = false;
        }else{
            products.add(product);
            b = true;
        }
        
        
        
        return b;
    }
    
    /**
     * loads initial test data into data source.
     */
    public List<Product> loadTestData() {    
                
        products.add( new Product("C01", "desc01", 101.0, 11) );
        products.add( new Product("C02", "desc02", 102.0, 12) );
        products.add( new Product("C03", "desc03", 103.0, 13) );
        
        
        return products;
        
        
    }   
    

    
    /*
     * find products with stock lower than given value.
     * @param stock the threshold value to search products.
     * @return list of products or null inc ase of error.
     */
    
    public List<Product> findProductWithLowStock(int stock){
            
            Product p;
            List<Product> list = new ArrayList<>();
            
            for(Product prod:products){
               
               p = prod;
               
               if(p.getStock()<= stock){
                    list.add(p);
                }
            }
            
              
                    
            return list;
        
    }
    
    /**
     * modifies a product in the data source.
     * @param currentProduct
     * @param newProduct
     * @return true if successfully modified, false otherwise
     */
    public boolean modProduct(Product currentProduct, Product newProduct){
        boolean b = false;   
        int index;
        Iterator<Product> iter = products.iterator();
        Product p = null;
        
        index = products.indexOf(currentProduct);
        
        for(Product prod:products){
            
            p = iter.next();
            
            if(products.indexOf(p)!=index){
                if(p.getCode().equals(currentProduct.getCode())){
                    b = false;
                }
                
                
            }else{
                b = true;
            }
        }
        
        
        

        
        if(b==true){
            products.set(index,newProduct);
        }
        
        
        return b;    
    }
    /**
     * Delete an object from datasource
     * @param Product p to remove
     * @return false if not removed, true if it was
     */
    public boolean remProduct(Product p){
        
        boolean b = false;
        
        if(p==null){
            b = false;
        }else{
            products.remove(p);
            b = true;
        }
        
        
        return b;
                
    }
}
