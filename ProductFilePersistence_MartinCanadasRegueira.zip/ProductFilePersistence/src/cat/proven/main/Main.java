/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.main;

import cat.proven.model.Persistence.Persistence;
import cat.proven.model.Model;
import cat.proven.model.Product;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author mati
 */
public class Main {

    

    Model model = new Model();
    Persistence filePersistence = new Persistence();
    List <Product> list = new ArrayList<>();
    List <Product> viewList = new ArrayList<>();
    
    
    
    
    public static void main(String[] args) {
        
        Main myMain = new Main();
        
        myMain.menu();        
        
    }
    
    public void menu() {
        
        boolean confirm;
        
        list = model.listAllProducts();
        
        int menuOption;
        
        Scanner sc = new Scanner(System.in);
        String productsFile = "./files/products.txt";
                
        
        do {

            System.out.println("**** MAIN MENU: ****");
            System.out.println("0. Exit.");
            System.out.println("1. Write file.");
            System.out.println("2. Read file.");
            System.out.println("3. Show Products.");
            System.out.println("Select an option: ");
            menuOption = sc.nextInt();

            switch (menuOption) {

                case 0:
                    System.out.println("Closing");
                    break;
                case 1:
                    confirm = filePersistence.writeFile(list, productsFile);
                    if (confirm) {
                        System.out.println("Succesful.");
                    } else {
                        System.out.println("Error.");
                    }
                    break;
                case 2:
                    list = filePersistence.readFile(productsFile);
                    break;
                case 3:
                    showProducts(list);
                    break;
                default:
                    System.out.println("Is not a given option.");

            }

        } while (menuOption != 0);


        
        
        
        
        
        
    }
    
    
    
    
    public void showProducts(List<Product> list) {
        
        for (Product product : list) {
            
            System.out.println(product.toString());
            
        }
        
        
    }
    
}
